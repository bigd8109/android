### Overview
For usage questions: ask on
[Stack  Overflow](http://stackoverflow.com/questions/tagged/material-components).

 - Context, problem or idea, solution or next step
 - Screenshots/Video (if possible)
 - Stack trace (if possible)

### Reproduction steps

 - Detailed steps to reproduce

### Version number

 - Found in CHANGELOG.md

### Operating system and device

### Related issues

 - Type `#` and the issue number or `#` and select the from the inline drop down.
